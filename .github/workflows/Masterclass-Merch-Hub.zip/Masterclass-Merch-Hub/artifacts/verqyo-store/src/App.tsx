import { useEffect, useState, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { ArrowDown, ArrowRight, ArrowUpRight, Menu, Minus, Plus, ShoppingBag, X } from 'lucide-react';
import {
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';

const queryClient = new QueryClient();

function Home() {
  const [bagOpen, setBagOpen] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [activeProduct, setActiveProduct] = useState<Product | null>(null);
  const [selectedSize, setSelectedSize] = useState('M');
  const [bag, setBag] = useState<BagItem[]>(() => {
    try { return JSON.parse(localStorage.getItem('verqyo-bag') || '[]') as BagItem[]; } catch { return []; }
  });
  useEffect(() => { localStorage.setItem('verqyo-bag', JSON.stringify(bag)); }, [bag]);
  useEffect(() => {
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') { setBagOpen(false); setActiveProduct(null); setMobileOpen(false); }
    };
    window.addEventListener('keydown', closeOnEscape);
    return () => window.removeEventListener('keydown', closeOnEscape);
  }, []);
  const addToBag = () => {
    if (!activeProduct) return;
    setBag((current) => {
      const existing = current.find((item) => item.id === activeProduct.id && item.size === selectedSize);
      return existing
        ? current.map((item) => item === existing ? { ...item, quantity: item.quantity + 1 } : item)
        : [...current, { ...activeProduct, size: selectedSize, quantity: 1 }];
    });
    setActiveProduct(null);
    setBagOpen(true);
  };
  const changeQuantity = (id: string, size: string, amount: number) => setBag((current) =>
    current.map((item) => item.id === id && item.size === size ? { ...item, quantity: item.quantity + amount } : item)
      .filter((item) => item.quantity > 0));
  const bagCount = bag.reduce((sum, item) => sum + item.quantity, 0);
  const openProduct = (product: Product) => { setSelectedSize('M'); setActiveProduct(product); };
  const navItems = [['Collections', '#collections'], ['Limited', '#limited'], ['Our point of view', '#identity'], ['Custom', '#custom']];
  return (
    <div className="site-shell">
      <div className="announcement">Online only&nbsp;&nbsp; / &nbsp;&nbsp;Made to be yours</div>
      <header className="nav-wrap">
        <nav className="nav" aria-label="Main navigation">
          <a href="#top" aria-label="VERQYO home"><img className="wordmark" src="/brand/verqyo-logo.png" alt="VERQYO symbol and wordmark — Wear Your Identity" /></a>
          <div className="nav-links">{navItems.map(([label, href]) => <a key={href} href={href}>{label}</a>)}</div>
          <div className="nav-actions">
            <button className="nav-action" onClick={() => setBagOpen(true)} aria-label={`Open bag, ${bagCount} items`} data-testid="button-open-bag">
              Bag <span className="bag-count">{bagCount}</span>
            </button>
            <button className="menu-toggle" onClick={() => setMobileOpen((value) => !value)} aria-label={mobileOpen ? 'Close navigation menu' : 'Open navigation menu'} aria-expanded={mobileOpen} data-testid="button-mobile-menu">
              {mobileOpen ? <X size={19} /> : <Menu size={19} />}
            </button>
            <button className="nav-action" onClick={() => setBagOpen(true)} aria-label="Open bag" data-testid="button-bag-icon"><ShoppingBag size={17} /></button>
          </div>
          {mobileOpen && <div className="mobile-nav">{navItems.map(([label, href]) => <a key={href} href={href} onClick={() => setMobileOpen(false)}>{label}</a>)}</div>}
        </nav>
      </header>
      <main>
        <section className="hero" id="top">
          <div className="hero-copy">
            <div className="eyebrow">A quieter kind of statement</div>
            <h1><span>Wear</span><span className="outline">your</span><span>identity.</span></h1>
            <p>For people who say enough without saying too much. Considered essentials. A mark that means something to you.</p>
            <div className="hero-ctas">
              <a href="#collections" className="button-dark">Explore the pieces <ArrowRight size={14} /></a>
              <a href="#identity" className="text-link">Our point of view <ArrowDown size={13} /></a>
            </div>
          </div>
          <div className="hero-art">
            <span className="hero-note">VERQYO / WEAR YOUR IDENTITY</span>
            <img src="/brand/853474376_1103870888933577_5092391239370279369_n_1792599954131.jpg" alt="VERQYO white graphic tee, photographed against a quiet stone surface" />
          </div>
        </section>
        <div className="ticker" aria-label="VERQYO, wear your identity">
          <span>Wear your identity &nbsp;·&nbsp; The wordmark stays small &nbsp;·&nbsp; The rest is yours &nbsp;·&nbsp; Quiet by design &nbsp;·&nbsp; Wear your identity &nbsp;·&nbsp; The wordmark stays small &nbsp;·&nbsp; The rest is yours &nbsp;·&nbsp; Quiet by design &nbsp;·&nbsp;</span>
        </div>

        <section className="section collections" id="collections">
          <div className="section-head">
            <div><div className="eyebrow">Find your form</div><h2>Four ways to<br />make it yours.</h2></div>
            <p>One point of view. Four expressions. Choose the silhouette that feels like you.</p>
          </div>
          <div className="collection-grid">
            <CollectionCard className="tall" image="/brand/850988145_2492320811276681_5301498486274894184_n_1792599954128.jpg" title="Oversized" detail="Room to move. Space to be." onClick={() => openProduct(products[0])} />
            <CollectionCard image="/brand/857756040_1449079307435084_8613425784059299733_n_1792599954133.jpg" title="Fitted" detail="A closer kind of confidence." onClick={() => openProduct(products[1])} />
            <CollectionCard image="/brand/856047691_1487012756905479_7824839123862437561_n_1792599954132.jpg" title="Limited editions" detail="Made in considered numbers." onClick={() => { document.getElementById('limited')?.scrollIntoView({ behavior: 'smooth' }); }} />
            <CollectionCard image="/brand/851373995_1094831196517266_7562210692553415189_n_1792599954129.jpg" title="Custom design" detail="Your idea. Made personal." onClick={() => { document.getElementById('custom')?.scrollIntoView({ behavior: 'smooth' }); }} />
          </div>
        </section>

        <section className="section dark-section" id="limited">
          <div className="product-feature">
            <div className="feature-image"><img src="/brand/856047691_1487012756905479_7824839123862437561_n_1792599954132.jpg" alt="Close detail of the VERQYO embroidered mark on black fabric" /></div>
            <div className="feature-copy">
              <div className="eyebrow">Small run / considered detail</div>
              <h2>Quiet<br />doesn’t mean<br />ordinary.</h2>
              <p>A familiar silhouette, finished with an embroidered VERQYO mark. Designed to be noticed up close, and worn on your terms.</p>
              <div className="feature-data">
                <div><span>Colour</span><span>Black / tonal mark</span></div>
                <div><span>Fit</span><span>Relaxed unisex</span></div>
                <div><span>Detail</span><span>Raised embroidery</span></div>
              </div>
              <button className="button-dark" onClick={() => openProduct(products[2])} data-testid="button-preview-limited">Preview this piece <ArrowUpRight size={14} /></button>
              <div className="price-note">Illustrative pricing only. Contact us to confirm product details and availability.</div>
            </div>
          </div>
        </section>

        <section className="section" id="identity">
          <div className="manifesto">
            <div className="manifesto-kicker">The VERQYO point of view / 01</div>
            <div><h2>The wordmark stays small.<br /><em>The rest is yours.</em></h2>
              <p>We believe what you wear can say something without raising its voice. Clean forms. Deliberate detail. Space for the person wearing it to be the point.</p>
            </div>
          </div>
        </section>

        <section className="custom-panel" id="custom">
          <img src="/brand/851890857_1108643648763620_2311981907429151878_n_1792599954130.jpg" alt="" aria-hidden="true" />
          <div className="custom-inner">
            <div className="eyebrow">Made around your idea</div>
            <h2>Make it<br />personal.</h2>
            <p>Have a design in mind, or a question about a piece? Tell us what you’re thinking. Custom enquiries are welcome.</p>
            <a className="button-dark" href="mailto:verqyo.official@gmail.com?subject=VERQYO%20custom%20enquiry">Start a conversation <ArrowUpRight size={14} /></a>
          </div>
        </section>
      </main>
      <footer className="footer" id="contact">
        <div className="footer-main">
          <div className="footer-brand">
            <img className="footer-logo" src="/brand/verqyo-logo.png" alt="VERQYO symbol and wordmark" />
            <div className="footer-tag">WEAR YOUR IDENTITY.</div>
          </div>
          <div><h3>Talk to us</h3>
            <a href="mailto:verqyo.official@gmail.com">verqyo.official@gmail.com</a>
            <a href="tel:+9779743397271">+977 9743397271</a>
            <p>Product questions, purchase enquiries<br />and custom work.</p>
          </div>
          <div><h3>Find your way</h3>
            <a href="#collections">Collections</a><a href="#limited">Limited editions</a><a href="#custom">Custom design</a>
            <h3 style={{ marginTop: 22 }}>Social</h3>
            <a href="mailto:verqyo.official@gmail.com?subject=VERQYO%20social%20profile%20enquiry">Ask us for our social profiles <ArrowUpRight size={12} style={{ display: 'inline', verticalAlign: 'middle' }} /></a>
          </div>
        </div>
        <div className="footer-bottom"><span>© VERQYO — Wear your identity.</span><span>Online only / Contact us for current availability</span><a href="#top">Back to top ↑</a></div>
      </footer>

      {bagOpen && <div className="overlay" onMouseDown={(event) => { if (event.target === event.currentTarget) setBagOpen(false); }}>
        <aside className="drawer" role="dialog" aria-modal="true" aria-labelledby="bag-title">
          <div className="drawer-head"><h2 id="bag-title">Your bag <span className="mono" style={{ fontSize: 13, color: '#777' }}>({bagCount})</span></h2><button className="icon-button" onClick={() => setBagOpen(false)} aria-label="Close bag" data-testid="button-close-bag"><X size={19} /></button></div>
          {bag.length === 0 ? <div className="bag-empty"><ShoppingBag size={24} strokeWidth={1} style={{ margin: '0 auto 20px' }} /><p>Your bag is waiting.</p><button className="text-link" onClick={() => setBagOpen(false)}>Explore the pieces <ArrowRight size={13} /></button></div> :
            <>{bag.map((item) => <div className="bag-item" key={`${item.id}-${item.size}`}>
              <img src={item.image} alt={item.name} /><div><h3>{item.name}</h3><p>Size {item.size} · {item.color}</p><p>Illustrative price · ${item.price}</p>
                <div className="bag-row"><div className="quantity"><button onClick={() => changeQuantity(item.id, item.size, -1)} aria-label={`Remove one ${item.name}`} data-testid={`button-decrease-${item.id}`}><Minus size={12} /></button><span>{item.quantity}</span><button onClick={() => changeQuantity(item.id, item.size, 1)} aria-label={`Add one ${item.name}`} data-testid={`button-increase-${item.id}`}><Plus size={12} /></button></div>
                  <button className="text-link" onClick={() => changeQuantity(item.id, item.size, -item.quantity)} aria-label={`Remove ${item.name} from bag`}>Remove</button></div>
              </div></div>)}
              <p className="price-note" style={{ lineHeight: 1.7, marginTop: 22 }}>Your bag is a local preview only. Checkout and payment are not connected. Contact us to confirm availability, pricing and purchase details.</p>
              <a className="button-dark" style={{ width: '100%', marginTop: 18 }} href="mailto:verqyo.official@gmail.com?subject=VERQYO%20purchase%20enquiry">Ask about your selection <ArrowRight size={14} /></a>
            </>}
        </aside>
      </div>}

      {activeProduct && <div className="modal-wrap" onMouseDown={(event) => { if (event.target === event.currentTarget) setActiveProduct(null); }}>
        <section className="product-modal" role="dialog" aria-modal="true" aria-labelledby="product-title">
          <button className="icon-button modal-close" onClick={() => setActiveProduct(null)} aria-label="Close product preview" data-testid="button-close-product"><X size={19} /></button>
          <div className="modal-photo"><img src={activeProduct.image} alt={activeProduct.name} /></div>
          <div className="modal-info">
            <div className="eyebrow">{activeProduct.collection}</div>
            <h2 id="product-title">{activeProduct.name}</h2>
            <p>{activeProduct.description}</p>
            <p className="mono" style={{ color: '#20201e', marginTop: 16 }}>Illustrative price · ${activeProduct.price}</p>
            <span className="size-label">Choose a size</span>
            <div className="sizes" role="group" aria-label="Choose size">{['S', 'M', 'L', 'XL'].map((size) =>
              <button key={size} className={`size-btn${selectedSize === size ? ' selected' : ''}`} aria-pressed={selectedSize === size} onClick={() => setSelectedSize(size)} data-testid={`button-size-${size}`}>{size}</button>)}</div>
            <button className="button-dark" style={{ width: '100%', marginTop: 28 }} onClick={addToBag} data-testid="button-add-to-bag">Add to local bag <ShoppingBag size={14} /></button>
            <div className="price-note">Preview only. No checkout or payment is connected.</div>
          </div>
        </section>
      </div>}
    </div>
  );
}

type Product = { id: string; name: string; collection: string; image: string; description: string; price: number; color: string };
type BagItem = Product & { size: string; quantity: number };
const products: Product[] = [
  { id: 'oversized-mark', name: 'Identity / Oversized', collection: 'Oversized', image: '/brand/850988145_2492320811276681_5301498486274894184_n_1792599954128.jpg', description: 'A relaxed shape with a considered chest mark. Crisp, easy, and made to feel like your own.', price: 42, color: 'Black' },
  { id: 'fitted-mark', name: 'Identity / Fitted', collection: 'Fitted', image: '/brand/857756040_1449079307435084_8613425784059299733_n_1792599954133.jpg', description: 'A closer cut, finished with the VERQYO wordmark. A little less volume. No less presence.', price: 38, color: 'White' },
  { id: 'embroidered-mark', name: 'Quiet Mark / Embroidered', collection: 'Limited edition', image: '/brand/856047691_1487012756905479_7824839123862437561_n_1792599954132.jpg', description: 'A familiar black tee, made distinct by raised embroidery. An understated signature, best seen up close.', price: 48, color: 'Black' },
];

function CollectionCard({ image, title, detail, className = '', onClick }: { image: string; title: string; detail: string; className?: string; onClick: () => void }) {
  return <button className={`collection-card ${className}`} onClick={onClick} aria-label={`Explore ${title}`} data-testid={`button-collection-${title.toLowerCase().replaceAll(' ', '-')}`}>
    <img src={image} alt={`${title} VERQYO apparel`} loading="lazy" />
    <span className="collection-info"><span><h3>{title}</h3><p>{detail}</p></span><span className="circle-arrow"><ArrowUpRight size={17} /></span></span>
  </button>;
}

function Router() {
  return (
    // Keep a shared shell (sidebar, navbar) outside the boundary so it
    // survives a page crash.
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
